document.body.onkeyup = function(e) {
  console.log(e.key);
  if (e.key == "d") {
    document.body.classList.toggle("dark");
  }
}